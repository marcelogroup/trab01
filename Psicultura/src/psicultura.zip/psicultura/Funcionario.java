/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package psicultura;

/**
 *
 * @author marcelo
 */
public class Funcionario extends Pessoa{
    public int id_tanque;
    
    public void funcionario(String nome,int cpf,int identidade,String endereco,String turno,String contato,int id_empregados,int id_tanque ){
        this.nome = nome;
        this.cpf  = cpf;
        this.identidade = identidade;
        this.endereco = endereco;
        this.turno =turno;
        this.contato=contato;
        this.id_empregados=id_empregados;
        this.id_tanque=id_tanque;
    }
}
