/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package psicultura;

import java.util.Date;

/**
 *
 * @author marcelo
 */
public class HistoricoMedicao extends Tanque{
    public Date data_medicao;
    
    public void historico(float temp,float oxi,float ph,int id_tanque,int id_empregado,Date data_medicao){
        this.sensor_temp=temp;
        this.sensor_oxi=oxi;
        this.sensor_ph=ph;
        this.id_tanque=id_tanque;
        this.id_empregado=id_empregado;
        this.data_medicao=data_medicao;
    }
}
