/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Psicultura;

/**
 *
 * @author 20151BSI0436
 */
public class Peixe {
    public int id;
    public String especie;
    public float tempMin;
    public float tempMax;
    public float phMin;
    public float phMax;
    public float oxiMin;//mgO2/L
    public float oxiMax;
    public String tipoAgua;
    
    public Peixe(int id, String esp, String agua,float tmin,float tmax,float pmin,float pmax,float omin,float omax){
        this.id=id;
        this.especie=esp;
        this.tipoAgua=agua;
        this.tempMax=tmax;
        this.tempMin=tmin;
        this.phMax=pmax;
        this.phMin=pmin;
        this.oxiMax=omax;
        this.oxiMin=omin;
    }
}
