/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Psicultura;

public class Tanque {
    public float sensor_temp;
    public float sensor_oxi;
    public float sensor_ph;
    public int id_tanque;
    public Funcionario empregado;
    public Peixe peixe;
    
    public Tanque(float temp,float oxi,float ph,int id_tanque,Funcionario empregado, Peixe tipoPeixe){
    this.sensor_temp=temp;
    this.sensor_oxi=oxi;
    this.sensor_ph=ph;
    this.id_tanque=id_tanque;
    this.empregado=empregado;
    this.peixe= tipoPeixe;
    }
    
    boolean verificaOxigenacao(){
        return this.peixe.oxiMin<=this.sensor_oxi && this.peixe.oxiMax>=this.sensor_oxi;
    }
    boolean verificaTemp(){
        return this.peixe.tempMin<=this.sensor_temp && this.peixe.tempMax>=this.sensor_temp;
    }
    boolean verificaPH(){
        return this.peixe.phMin<=this.sensor_ph && this.peixe.phMax>=this.sensor_ph;
    }
    
    public void analise(){
        if(!verificaOxigenacao()){
            System.out.println("PROBLEMA NA OXIGENACAO!!!!!!");
        }
        if(!verificaTemp()){
            System.out.println("PROBLEMA NA TEMPERATURA!!!!!!");
        }
        if(!verificaPH()){
            System.out.println("PROBLEMA NO PH!!!!!!");
        }
    }
    
    
}
