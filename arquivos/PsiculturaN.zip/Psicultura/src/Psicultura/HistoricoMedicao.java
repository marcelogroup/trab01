/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Psicultura;

import java.util.Date;

/**
 *
 * @author marcelo
 */
public class HistoricoMedicao {
    public Date data_medicao;
    public float dadostemp;
    public float dadosoxi;
    public float dadosph;
    public Tanque tanque;
    
    public HistoricoMedicao(Tanque tanqueN){
        this.tanque=tanqueN;
    }
    public void printHistorico(){
        this.dadostemp=this.tanque.sensor_temp;
        this.dadosoxi=this.tanque.sensor_oxi;
        this.dadosph=this.tanque.sensor_ph;
        this.data_medicao=new Date();
        System.out.println("Analise data:"+ this.data_medicao+"\nTemperatura atual:"+this.dadostemp+"°C\nOxigenacao Atual:"+this.dadosoxi+"mgO2/L\nPH Atual:"+this.dadosph);
      
    }
}
