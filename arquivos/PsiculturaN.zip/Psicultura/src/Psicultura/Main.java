/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Psicultura;


/**
 *
 * @author André
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Funcionario novoFunc= new Funcionario("Joao",1010,20141,"Rua alameda rodovia","vespertino","40028922",2);
        Gerente novoGen= new Gerente("Pedro",2020,10342,"Avenida rua alameda","vespertino","05002018",1);
        Peixe novop= new Peixe(1,"Tucunaré","Doce",18f,30f,6f,9f,13f,16f);
        Tanque novoTanque= new Tanque(29f,15f,7f,1,novoFunc,novop);
        novoTanque.analise();
        HistoricoMedicao historico= new HistoricoMedicao(novoTanque);
        historico.printHistorico();
        
    }
    
}
